from django.shortcuts import render, get_object_or_404
from .models import Product
from django.core.paginator import Paginator

def index(request):
    query = request.GET.get('q')  
    if query:
        products = Product.objects.filter(name__icontains=query)
    else:
        products = Product.objects.all()
    

    paginator = Paginator(products, 10)  # 10 ta mahsulot
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    return render(request, 'product/index.html', {'page_obj': page_obj, 'query': query})

def product_detail(request, id):
    product = get_object_or_404(Product, id=id)
    related_products = Product.objects.filter(category=product.category).exclude(id=id)[:4]  

    return render(request, 'product/product_detail.html', {
        'product': product,
        'related_products': related_products,
    })


