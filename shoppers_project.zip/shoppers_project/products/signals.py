from django.db.models.signals import post_save
from django.dispatch import receiver
from .models import Product

@receiver(post_save, sender=Product)
def notify_product_creation(sender, instance, created, **kwargs):
    if created:
        print(f"Yangi mahsulot yaratildi: {instance.name}")


@receiver(post_save, sender=User)
def notify_user_update(sender, instance, **kwargs):
    print(f"Foydalanuvchi yangilandi: {instance.username}")
